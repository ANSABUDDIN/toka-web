import React from 'react'

const EarnmoreSec = () => {
    return (
        <>
            <div className="container position-r">
                <img src="/assets/images/rounded-fan.png" className='rounded-fan-2 d-lg-block d-none' alt="" />

                <div className="center-div d-flex flex-lg-row flex-column justify-content-center">
                    <div className="text-center">
                        <h1 className="text-color">Want to earn more <br className="d-lg-block d-none" /> on crypto?</h1>
                        <p className="banner-description mb-0 mt-2">It is an exciting time to become a trader.</p>
                        <button className='btn-global'>
                            Start Now
                        </button>
                    </div>
                </div>
            </div>
        </>
    )
}

export default EarnmoreSec

