import React from 'react'
import Card from '../elements/Card';
const CardSec = () => {
    return (
        <>
            <section className="pt-5 text-light mb-4">
                <div className="container">
                    <div className="text-light">
                        <div className='d-flex  justify-content-center gap-2'>
                            <h1 className='fw-bold  heading-font text-color'>Hear from the </h1>
                            <span className='gradient '>
                                <h1 className='fw-bold heading-font'>
                                    clients
                                </h1>
                            </span>
                        </div>
                        <div className='text-center'>
                            <p className="a-color pt-3 ">Connect our AI to your exchange account and invest crypto <br
                                className="d-lg-block d-none" /> automatically. Toka app work while you just live.</p>
                        </div>
                    </div>
                    <div className="d-flex gap-lg-5 gap-2 flex-lg-row flex-column">
                        <Card />
                        <Card />


                    </div>
                    <div className="d-flex gap-lg-5 gap-1  flex-lg-row flex-column">
                        <Card />
                        <Card />


                    </div>


                </div>
            </section>
        </>
    )
}

export default CardSec