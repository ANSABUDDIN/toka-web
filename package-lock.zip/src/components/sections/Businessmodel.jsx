import React from 'react'

const Businessmodel = () => {
    return (
        <>
            <div className='banner container my-lg-5 py-3 py-lg-5' style={{borderBottom:"0px"}}>
                <div className="row align-items-center">
                    <div className="col-lg-6 col-md-6 col-12 p-2 p-lg-5 text-lg-start text-center">
                        <div className='d-flex justify-content-lg-start justify-content-center gap-2'>
                            <span className=" fs-0 text-color heading-font fw-bold">Business </span>
                            <span className='gradient'>
                                <span className=" fs-0 heading-font fw-bold">model</span>
                            </span>

                        </div>
                        <p className='banner-description mb-0 mt-2'>
                            Invest in Bitcoin, Ethereum, USDT, and other cryptocurrencies using our crypto trading app. The Bitcoin and cryptocurrency markets have experienced a surge in volume recently, making it is an exciting time to become a trader. Connect our AI to your exchange account and invest crypto automatically. Toka app work while you just live.
                        </p>
                        <button className='btn-global-2 mt-4'>
                            Learn More
                        </button>
                    </div>
                    <div className="col-lg-6 col-md-6 col-12 position-r">
                        {/* <img src="/assets/images/rounded-fan.png" className='rounded-fan d-lg-block d-none' alt="" /> */}

                        <img src="assets/images/hand-with-ball.png" className='img-fluid' alt="" />
                        <img src="assets/images/squre-bcak-hand.png" className='back-img-2 img-fluid' alt="" />

                    </div>

                </div>
            </div>
        </>
    )
}

export default Businessmodel