import React from 'react'
import BallCard from '../elements/BallCard'

const AdvantageSec = () => {
    return (
        <>
            <div className="container position-r my-5">
                <img src="/assets/images/rounded-fan.png" className='rounded-fan-2 d-lg-block d-none' alt="" />

                <div className="center-div  d-flex flex-column justify-content-center">
                    <div className="text-center">
                        <div className='d-flex justify-content-center gap-2'>
                            <h1 className="text-color">Main</h1>
                            <span className='gradient'>

                                <h1 className="text-light">advantages</h1>
                            </span>
                        </div>
                        <p className="banner-description mb-0 mt-2">Connect our AI to your exchange account and invest crypto <br className='d-lg-block d-none' /> automatically. Toka app work while you just live.</p>
                        <div className="row">
                            <div className="col-4">

                            </div>
                        </div>
                    </div>
                    <div className='row'>
                        <BallCard />
                        <BallCard />
                        <BallCard />
                        <BallCard />
                        <BallCard />
                        <BallCard />
                        
                    </div>
                </div>
            </div>


        </>
    )
}

export default AdvantageSec